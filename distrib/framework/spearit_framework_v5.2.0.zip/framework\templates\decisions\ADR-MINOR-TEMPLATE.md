# ADR-NNN: [Decision Title]

**Status:** [Proposed | Accepted | Deprecated | Superseded by ADR-XXX]
**Date:** YYYY-MM-DD
**Deciders:** [Names]
**Impact:** Minor
**Scope:** [Specific module/file affected]
**Supersedes:** [ADR-XXX or None]

---

## Context

What problem are we solving?

---

## Options

1. **Option A:** Description
   - Pros: ...
   - Cons: ...

2. **Option B:** Description
   - Pros: ...
   - Cons: ...

---

## Decision

We chose **[Option X]** because:
- Reason 1
- Reason 2

**Implementation:** [Location/files]

---

## Consequences

**Good:**
- ...

**Bad:**
- ...

**Revisit if:** [Condition that would make us reconsider]

---

## References

- [If applicable]
