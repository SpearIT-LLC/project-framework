#!/usr/bin/env bash
# .claude/scripts/fw-move.sh — Work item move execution engine
#
# Handles all deterministic move operations and policy hard-blocks.
# The AI layer (fw-move command) handles interactive recovery and post-move actions.
#
# Usage:
#   bash .claude/scripts/fw-move.sh <item-id-or-list> <target-folder> [--force]
#
# --force: Reserved for future soft-block bypass. Dependency checks on → doing/
#          and acceptance-criteria checks on → done/ are always enforced
#          regardless of --force (both are hard blocks).
#
# Handles:
#   - Single or batch IDs (comma/space separated)
#   - Full IDs (FEAT-145), bare numeric (145), mixed
#   - Parent + child auto-move
#   - Any file extension
#   - Untracked file fallback (mv when git mv fails)
#   - WIP limit warning for doing/ (warning only, does not block)
#
# Hard blocks (exit 1, --force has no effect):
#   - Invalid transition (transition matrix)
#   - Dependency not in done/ (→ doing only)
#   - Unchecked acceptance criteria (→ done only)
#
# Ripeness (BUG-184): there is NO deterministic readiness gate on → todo/backlog.
#   Per ADR-007 D7, plan ripeness is a judgment grep cannot make. It is enforced
#   behaviorally by the AI pre-implementation review at the → doing command layer.
#
# Examples:
#   bash .claude/scripts/fw-move.sh FEAT-145 doing
#   bash .claude/scripts/fw-move.sh "FEAT-145, FEAT-146" todo
#   bash .claude/scripts/fw-move.sh "145, 146" done
#   bash .claude/scripts/fw-move.sh "FEAT-145, 146" todo --force

set -uo pipefail

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
VALID_FOLDERS="backlog todo doing done blocked archive releases"
FORCE=false

# ---------------------------------------------------------------------------
# Repo root guard
# ---------------------------------------------------------------------------
REPO_ROOT=$(git rev-parse --show-toplevel 2>/dev/null) || {
  echo "❌ Not inside a git repository."
  exit 1
}
cd "$REPO_ROOT"

WORK_DIR="project-hub/work"

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------

# Strip --force flag before positional parsing
FILTERED_ARGS=()
for arg in "$@"; do
  if [ "$arg" = "--force" ]; then
    FORCE=true
  else
    FILTERED_ARGS+=("$arg")
  fi
done
set -- "${FILTERED_ARGS[@]}"

if [ $# -lt 2 ]; then
  echo "Usage: $0 <item-id-or-list> <target-folder> [--force]"
  echo "Valid targets: $VALID_FOLDERS"
  exit 1
fi

# Last argument is the target folder
TARGET="${!#}"

# Validate target
if ! echo "$VALID_FOLDERS" | grep -qw "$TARGET"; then
  echo "❌ Invalid target folder: '$TARGET'"
  echo "   Valid targets: $VALID_FOLDERS"
  exit 1
fi

# Everything except the last arg is the item list
ALL_ARGS=("$@")
ITEM_ARGS=("${ALL_ARGS[@]:0:${#ALL_ARGS[@]}-1}")
RAW_LIST="${ITEM_ARGS[*]}"

# Strip surrounding quotes, split on commas/spaces, filter out folder names
IFS=', ' read -ra TOKENS <<< "$RAW_LIST"
ITEM_IDS=()
for TOKEN in "${TOKENS[@]}"; do
  TOKEN=$(echo "$TOKEN" | tr -d '",')
  [ -z "$TOKEN" ] && continue
  echo "$VALID_FOLDERS" | grep -qw "$TOKEN" && continue
  ITEM_IDS+=("$TOKEN")
done

if [ ${#ITEM_IDS[@]} -eq 0 ]; then
  echo "❌ No item IDs provided."
  exit 1
fi

# ---------------------------------------------------------------------------
# ID normalization: strip type prefix, extract numeric ID
# FEAT-125 → 125, feat-125 → 125, 125 → 125
# ---------------------------------------------------------------------------
normalize_id() {
  echo "$1" | sed 's/^[A-Za-z]*[-_]*//' | tr '[:upper:]' '[:lower:]'
}

# ---------------------------------------------------------------------------
# Find all parent files for a numeric ID (any extension, excludes children)
# ---------------------------------------------------------------------------
find_parent() {
  local numeric_id="$1"
  find "$WORK_DIR" -type f \
    | grep -iE "[-]${numeric_id}([-.]|$)" \
    | grep -ivE "[-]${numeric_id}[.][0-9]" \
    || true
}

# ---------------------------------------------------------------------------
# Find all child files for a numeric ID
# ---------------------------------------------------------------------------
find_children() {
  local numeric_id="$1"
  find "$WORK_DIR" -type f \
    | grep -iE "[-]${numeric_id}[.][0-9]" \
    || true
}

# ---------------------------------------------------------------------------
# POLICY: Transition matrix
# Defines INVALID from→to pairs. Any transition not listed here is allowed.
# ---------------------------------------------------------------------------
INVALID_TRANSITIONS=(
  "backlog:doing"
  "done:backlog"
  "done:todo"
  "done:doing"
)

check_transition() {
  local source_folder="$1"
  local target="$2"
  local item_name="$3"
  local pair="${source_folder}:${target}"

  for invalid in "${INVALID_TRANSITIONS[@]}"; do
    if [ "$pair" = "$invalid" ]; then
      echo "❌ Invalid transition for $item_name: $source_folder/ → $target/"
      case "$pair" in
        "backlog:doing")
          echo "   Must commit to work first: backlog → todo → doing" ;;
        "done:backlog"|"done:todo"|"done:doing")
          echo "   Completed items cannot be reopened. Create a new work item instead." ;;
      esac
      return 1
    fi
  done
  return 0
}

# ---------------------------------------------------------------------------
# POLICY: Dependency check (for → doing)
# Reads "Depends On:" field from item file, verifies each dependency is in done/
# Note: --force has no effect on this check. Dependencies are always enforced.
# ---------------------------------------------------------------------------
check_dependencies() {
  local item_file="$1"
  local item_name
  item_name=$(basename "$item_file")

  local deps_line
  deps_line=$(grep -i "^\*\*Depends On:\*\*" "$item_file" 2>/dev/null || true)

  [ -z "$deps_line" ] && return 0

  local deps_raw
  deps_raw=$(echo "$deps_line" | sed 's/\*\*Depends On:\*\*//i' | tr -d '*')

  local errors=0
  IFS=', ' read -ra DEP_TOKENS <<< "$deps_raw"
  for dep in "${DEP_TOKENS[@]}"; do
    dep=$(echo "$dep" | tr -d ' \t')
    [ -z "$dep" ] && continue

    local dep_numeric
    dep_numeric=$(normalize_id "$dep")

    local dep_in_done
    dep_in_done=$(find "$WORK_DIR/done" -type f \
      | grep -iE "[-]${dep_numeric}([-.]|$)" \
      | grep -ivE "[-]${dep_numeric}[.][0-9]" \
      || true)

    if [ -z "$dep_in_done" ]; then
      local dep_location
      dep_location=$(find_parent "$dep_numeric" | head -1)
      if [ -n "$dep_location" ]; then
        local dep_folder
        dep_folder=$(basename "$(dirname "$dep_location")")
        echo "❌ $item_name depends on $dep (currently in $dep_folder/) — must be in done/ first"
      else
        echo "❌ $item_name depends on $dep — not found in any folder"
      fi
      ((errors++)) || true
    fi
  done

  return $errors
}

# ---------------------------------------------------------------------------
# POLICY: Acceptance criteria check (for → done)
# Fails if any unchecked [ ] items exist in the file
# ---------------------------------------------------------------------------
check_acceptance_criteria() {
  local item_file="$1"
  local item_name
  item_name=$(basename "$item_file")

  local unchecked
  unchecked=$(grep -ce '- \[ \]' "$item_file" 2>/dev/null || true)
  unchecked=${unchecked:-0}

  if [ "$unchecked" -gt 0 ]; then
    echo "❌ $item_name has $unchecked unchecked acceptance criteria — cannot move to done/"
    echo "   Fix: mark all [ ] as [x] before completing"
    return 1
  fi
  return 0
}

# ---------------------------------------------------------------------------
# Ripeness note (BUG-184):
# There is deliberately NO deterministic readiness check on → todo/backlog/etc.
# Per ADR-007 D7, ripeness is a judgment grep cannot make ("grep cannot see a
# confident-but-thin plan"). The two real gates are:
#   • → done  — deterministic: check_acceptance_criteria (unchecked [ ] below)
#   • → doing — behavioral: the AI pre-implementation review at the command layer
# The former check_readiness() greps (TODO/TBD/DECIDE markers, Option A/B/C,
# bracketed placeholders) matched no real work-item convention and only ever
# produced false positives on well-planned items — removed in BUG-184.
# TECH-177 will later enrich the → done checkbox gate with Obsidian task markers.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Stamp Completed date (for → done) — BUG-167
# Writes **Completed:** <today> into the item header. Call ONLY after a
# confirmed-successful move into done/ (never on the failure path), so the
# date is never written to a file that did not actually move.
# Idempotent: if a Completed date is already set, leave it (first-completion
# wins). Fills a blank **Completed:** line if present, else inserts one after
# **Created:**. Stages the modified file so move + stamp are one change.
# ---------------------------------------------------------------------------
stamp_completed() {
  local moved_file="$1"   # path to the file AFTER it was moved into done/
  local today
  today=$(date +%Y-%m-%d)

  # Already has a real date (YYYY-MM-DD, not the template placeholder) → leave it.
  if grep -qE "^\*\*Completed:\*\* *[0-9]{4}-[0-9]{2}-[0-9]{2}" "$moved_file" 2>/dev/null; then
    git add "$moved_file" 2>/dev/null || true
    return 0
  fi

  if grep -qE "^\*\*Completed:\*\*" "$moved_file" 2>/dev/null; then
    # Blank/placeholder Completed line exists → replace the whole line.
    # Use a temp file to avoid sed -i portability issues (Git Bash/macOS/Linux).
    local tmp
    tmp=$(mktemp)
    awk -v d="$today" '
      /^\*\*Completed:\*\*/ && !done { print "**Completed:** " d; done=1; next }
      { print }
    ' "$moved_file" > "$tmp" && mv "$tmp" "$moved_file"
  else
    # No Completed line → insert one immediately after the Created line.
    local tmp
    tmp=$(mktemp)
    awk -v d="$today" '
      { print }
      /^\*\*Created:\*\*/ && !done { print "**Completed:** " d; done=1 }
    ' "$moved_file" > "$tmp" && mv "$tmp" "$moved_file"
  fi

  git add "$moved_file" 2>/dev/null || true
}

# ---------------------------------------------------------------------------
# WIP limit warning (for → doing) — warning only, does not block
# ---------------------------------------------------------------------------
if [ "$TARGET" = "doing" ] && [ -f "$WORK_DIR/doing/.limit" ]; then
  LIMIT=$(cat "$WORK_DIR/doing/.limit" | tr -d '[:space:]')
  COUNT=$(find "$WORK_DIR/doing" -type f ! -name ".limit" | wc -l | tr -d '[:space:]')
  if [ "$COUNT" -ge "$LIMIT" ]; then
    echo "⚠️  WIP limit: $COUNT/$LIMIT items already in doing/"
    echo ""
  fi
fi

echo "Moving ${#ITEM_IDS[@]} item(s) to $TARGET/..."
echo ""

# ---------------------------------------------------------------------------
# Pre-flight policy checks for all items before moving any
# Fail fast: if any item fails policy, abort the whole batch
# ---------------------------------------------------------------------------
POLICY_ERRORS=0

for ID in "${ITEM_IDS[@]}"; do
  numeric_id=$(normalize_id "$ID")
  all_parents=$(find_parent "$numeric_id")

  if [ -z "$all_parents" ]; then
    echo "❌ Not found: '$ID' (ID=$numeric_id)"
    ((POLICY_ERRORS++)) || true
    continue
  fi

  source=$(echo "$all_parents" | head -1)
  source_folder=$(basename "$(dirname "$source")")

  # Skip already-in-target (not a policy error, handled gracefully later)
  [ "$source_folder" = "$TARGET" ] && continue

  # Transition matrix — hard block, --force has no effect
  check_transition "$source_folder" "$TARGET" "$(basename "$source")" || ((POLICY_ERRORS++)) || true

  # Dependency check (→ doing only) — hard block, --force has no effect
  if [ "$TARGET" = "doing" ]; then
    check_dependencies "$source" || ((POLICY_ERRORS++)) || true
  fi

  # Acceptance criteria check (→ done only) — hard block, --force has no effect
  if [ "$TARGET" = "done" ]; then
    check_acceptance_criteria "$source" || ((POLICY_ERRORS++)) || true
  fi

  # Ripeness (BUG-184): no deterministic readiness gate on → todo/backlog/etc.
  # → done is gated deterministically (check_acceptance_criteria, above);
  # → doing ripeness is the AI pre-implementation review at the command layer.
done

if [ "$POLICY_ERRORS" -gt 0 ]; then
  echo ""
  echo "❌ $POLICY_ERRORS policy check(s) failed — no items moved"
  exit 1
fi

# ---------------------------------------------------------------------------
# Process each item
# ---------------------------------------------------------------------------
MOVED=0
SKIPPED=0
FAILED=0

move_item() {
  local raw_id="$1"
  local target="$2"
  local numeric_id
  numeric_id=$(normalize_id "$raw_id")

  local all_parents
  all_parents=$(find_parent "$numeric_id")

  if [ -z "$all_parents" ]; then
    echo "❌ Not found: '$raw_id' (ID=$numeric_id) — skipped"
    ((FAILED++)) || true
    return
  fi

  local source
  source=$(echo "$all_parents" | head -1)
  local item_name
  item_name=$(basename "$source")
  local source_folder
  source_folder=$(basename "$(dirname "$source")")

  # Skip if already in target
  if [ "$source_folder" = "$target" ]; then
    echo "⚠️  $item_name already in $target/ — skipped"
    ((SKIPPED++)) || true
    return
  fi

  local children
  children=$(find_children "$numeric_id")

  # Move all parent files (first gets ✅, siblings get +)
  local first_moved=false
  while IFS= read -r parent_file; do
    local pname move_note=""
    pname=$(basename "$parent_file")
    if git mv "$parent_file" "$WORK_DIR/$target/" 2>/dev/null; then
      :
    else
      local is_tracked
      git ls-files --error-unmatch "$parent_file" 2>/dev/null && is_tracked=true || is_tracked=false
      if [ "$is_tracked" = false ]; then
        if mv "$parent_file" "$WORK_DIR/$target/" 2>/dev/null; then
          move_note=" (untracked)"
        else
          echo "❌ mv failed for $pname"; ((FAILED++)) || true; continue
        fi
      else
        echo "❌ git mv failed for $pname"; ((FAILED++)) || true; continue
      fi
    fi
    # BUG-167: stamp Completed date only after a confirmed move into done/
    if [ "$target" = "done" ]; then
      stamp_completed "$WORK_DIR/$target/$pname"
    fi
    if [ "$first_moved" = false ]; then
      echo "✅ $pname → $target/$move_note"
      ((MOVED++)) || true; first_moved=true
    else
      echo "   + $pname → $target/$move_note"
    fi
  done <<< "$all_parents"

  # Move children
  if [ -n "$children" ]; then
    while IFS= read -r child; do
      local child_name child_tracked
      child_name=$(basename "$child")
      if git mv "$child" "$WORK_DIR/$target/" 2>/dev/null; then
        [ "$target" = "done" ] && stamp_completed "$WORK_DIR/$target/$child_name"
        echo "   ↳ $child_name"
      else
        git ls-files --error-unmatch "$child" 2>/dev/null && child_tracked=true || child_tracked=false
        if [ "$child_tracked" = false ]; then
          if mv "$child" "$WORK_DIR/$target/" 2>/dev/null; then
            [ "$target" = "done" ] && stamp_completed "$WORK_DIR/$target/$child_name"
            echo "   ↳ $child_name (untracked)"
          fi
        else
          echo "   ↳ ❌ git mv failed for $child_name"
        fi
      fi
    done <<< "$children"
  fi
}

for ID in "${ITEM_IDS[@]}"; do
  move_item "$ID" "$TARGET"
done

echo ""

# Final count
if [ -f "$WORK_DIR/$TARGET/.limit" ]; then
  LIMIT_TEXT=$(cat "$WORK_DIR/$TARGET/.limit" | tr -d '[:space:]')
else
  LIMIT_TEXT="∞"
fi
FINAL_COUNT=$(find "$WORK_DIR/$TARGET" -type f ! -name ".limit" | wc -l | tr -d '[:space:]')
echo "📊 $TARGET/: $FINAL_COUNT/$LIMIT_TEXT items"
echo "   ✅ moved: $MOVED  ⚠️  skipped: $SKIPPED  ❌ failed: $FAILED"
