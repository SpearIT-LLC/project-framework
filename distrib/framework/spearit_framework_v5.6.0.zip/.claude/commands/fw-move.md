# /fw-move - Move Work Item Between Folders

Move a work item between workflow folders with policy enforcement, transition validation, and proper git operations.

## Usage

```
/fw-move <item-id> <target-folder> [--force]
/fw-move "<id1>, <id2>" <target-folder> [--force]
```

## Arguments

- `item-id` (required): One or more work item IDs — full (`FEAT-145`), bare numeric (`145`), or mixed (`"FEAT-145, 146"`). Comma or space separated. Quote multi-item lists.
- `target-folder` (required): One of: `backlog`, `todo`, `doing`, `done`, `blocked`, `archive`, `releases`
- `--force` (optional): Reserved for future soft-block bypass. Has no effect on the hard blocks: `→ doing/` dependency checks and `→ done/` acceptance-criteria checks are always enforced. (There is no longer a deterministic readiness block on `→ todo/` — see Ripeness below.)

---

## What the Script Handles

`.claude/scripts/fw-move.sh` enforces these as hard blocks (exit 1):

- **Transition matrix** — invalid from→to pairs rejected
- **Dependency check** — `Depends On:` items must be in `done/` before `→ doing` (not bypassable)
- **Acceptance criteria** — unchecked `[ ]` items block `→ done` (not bypassable)
- **WIP limit** — warning only (does not block)

**Ripeness (BUG-184):** there is **no** deterministic readiness gate on `→ todo/`. Committing to work is not a ripeness assertion. Per ADR-007 D7, plan ripeness is a judgment `grep` cannot make; it is enforced behaviorally by the **pre-implementation review at `→ doing`** (see Post-Move → doing/). The two deterministic gates are the dependency check (`→ doing`) and the acceptance-criteria check (`→ done`).

If the script exits 1, report the error and offer interactive recovery:
- Unchecked acceptance criteria (`→ done`) → "Mark them complete?"
- Dependency not in done/ (`→ doing`) → "Move FEAT-NNN to done first?"
- Invalid transition → explain valid paths

---

## What the AI Layer Handles

**Parent + children:** When a parent ID is specified (e.g. `909`), the script auto-moves all children. Do NOT ask for clarification.

**Child split detection:** When a child ID is specified directly (e.g. `909.1`), check whether its parent is in a different folder than the target.
- Warn if target is `backlog`, `todo`, or `blocked`
- Skip warning if target is `doing`, `done`, or `archive`

```
⚠️  FEAT-909.1 is a child of FEAT-909 (currently in todo/).
    Moving FEAT-909.1 to backlog/ will split it from its parent.

    Options:
    1. Move FEAT-909.1 only (proceed as requested)
    2. Move FEAT-909 + all children to backlog/ instead

    Which would you prefer?
```

---

## Pre-Move (AI)

**Before calling the script:**
1. ✅ Check for child split (warn if needed — see above)
2. ✅ For `→ blocked`: prompt user to add blocked metadata first:
   - `**Blocked By:**`, `**External Reference:**`, `**Reported Date:**`, `**Expected Resolution:**`, `**Workaround:**`, `**Follow-up Actions:**`
3. ✅ For `→ archive`: prompt user to add cancellation metadata first:
   - `**Status:** Cancelled`, `**Cancelled Date:**`, `**Cancellation Reason:**`

For all other targets — no pre-checks needed. The script handles the rest.

---

## Execute Move

```bash
bash .claude/scripts/fw-move.sh <ids> <target> [--force]
```

After the script succeeds, check for an artifact folder and move it if present:

```bash
# For each moved item, check for artifact folder
SOURCE_DIR="project-hub/work/<source-folder>"
TARGET_DIR="project-hub/work/<target-folder>"
ARTIFACT_DIR="${SOURCE_DIR}/${ITEM_ID}"

if [ -d "$ARTIFACT_DIR" ]; then
  git mv "$ARTIFACT_DIR" "$TARGET_DIR/"
  echo "Moved artifact folder ${ITEM_ID}/ to ${TARGET_DIR}/"
fi
```

Report to the user if an artifact folder was moved (e.g., "Also moved artifact folder TECH-094/ to done/").

---

## Post-Move (AI)

### → doing/
1. ✅ Pre-implementation review (REQUIRED):
   - Read work item file completely
   - Identify open questions (TODO, TBD, DECIDE, Option A/B/C)
   - Present: what we're building, design decisions, open questions, scope
2. ✅ **STOP — wait for user confirmation before implementing**

**During implementation** — if work item has an Implementation Checklist with:
```markdown
<!-- ⚠️ AI: Complete items in order. STOP at each [ ] and wait for approval. -->
```
Follow step-by-step: mark `[x]` immediately after each step, stop and wait for approval before proceeding. User may say "continue to completion" to approve all remaining steps at once.

### → done/
1. ✅ `Completed` date is set automatically by `move.sh` (BUG-167) — no manual step. Do NOT hand-edit the date.
2. ✅ Update session history using `/fw-session-history`
3. ✅ Commit:
   ```bash
   git add .
   git commit -m "feat: Complete ITEM-NNN - [brief description]"
   ```
4. ✅ Count items in `project-hub/work/done/` and nudge if thresholds exceeded:
   - 10–14 items: "You now have N items in done/. Consider releasing soon."
   - 15+ items: "You have N items in done/ — this is a large release. Recommend releasing or splitting by theme."
   - Under 10: no nudge

### → archive/
1. ✅ Update session history noting cancellation
2. ✅ Commit: `git commit -m "chore: Cancel ITEM-NNN - [brief reason]"`

### → blocked/
- No immediate commit required

### All other targets
- No additional actions required

---

## Examples

```bash
/fw-move FEAT-042 todo                    # Single item — full ID
/fw-move 042 todo                         # Single item — bare numeric
/fw-move FEAT-042 doing                   # Start work (with pre-implementation review)
/fw-move FEAT-042 done                    # Complete work (blocks on unchecked [ ])
/fw-move "FEAT-042, FEAT-043" todo        # Batch — full IDs
/fw-move "042, 043" todo                  # Batch — bare numerics
/fw-move "FEAT-042, 043" todo             # Batch — mixed
/fw-move FEAT-099 archive                 # Cancel work (add metadata first)
/fw-move BUG-144 blocked                  # Block on external party (add metadata first)
```

---

## Policy Reference

Transition policy: `framework/docs/collaboration/workflow-guide.md#workflow-transitions`
Script source: `.claude/scripts/fw-move.sh`
