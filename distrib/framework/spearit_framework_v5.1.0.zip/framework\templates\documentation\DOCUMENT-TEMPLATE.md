# [Document Title]

**Purpose:** [One sentence describing what this document covers]
**Version:** 1.0.0
**Last Updated:** YYYY-MM-DD

---

## Table of Contents

<!-- Include TOC when document has 5+ sections or exceeds 200 lines -->

- [Section One](#section-one)
- [Section Two](#section-two)
- [Section Three](#section-three)
- [References](#references)

---

## Section One

[Content for first major section]

### Subsection

[Subsections as needed]

---

## Section Two

[Content for second major section]

---

## Section Three

[Content for third major section]

---

## References

- [Related Document](path/to/doc.md) - Brief description
- [External Resource](https://example.com) - Brief description

---

**Last Updated:** YYYY-MM-DD
