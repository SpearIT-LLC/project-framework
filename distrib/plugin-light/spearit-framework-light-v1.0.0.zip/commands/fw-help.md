# /spearit-framework-light:help - Framework Command Help

Show available framework commands or get help on a specific command.

## Usage

```
/spearit-framework-light:help [command-name]
```

## Arguments

- `command-name` (optional): Command to get help for (e.g., "move", "next-id")

## Behavior

When invoked with no arguments, list all available commands in a table:

| Command | Description | Status |
|---------|-------------|--------|
| `/spearit-framework-light:help` | Show this help message | Active |
| `/spearit-framework-light:move` | Move work item between folders with policy enforcement | Active |
| `/spearit-framework-light:next-id` | Get next available work item ID | Active |
| `/spearit-framework-light:session-history` | Generate or update session history | Active |

When invoked with a command name (e.g., `/spearit-framework-light:help move`), show detailed help for that command including:
- Full syntax
- All arguments with descriptions
- 2-3 examples
- Any relevant notes

## Examples

```
/spearit-framework-light:help              # List all commands
/spearit-framework-light:help move         # Show help for move command
/spearit-framework-light:help next-id      # Show help for next-id command
```

## Output Format

Use a clean, readable format with horizontal rules and tables where appropriate.

## Help Content Source

This command is the **single source of truth** for all plugin command help. When generating help for a specific command:

1. Read the command's `.md` file from the plugin's `commands/fw-<name>.md` directory
2. Extract and format:
   - Description (from first paragraph after title)
   - Syntax (from `## Usage` code block)
   - Subcommands/Arguments (from `## Subcommands` or `## Arguments`)
   - Examples (from `## Examples`)
3. Present in a consistent format

Commands that receive `help` as an argument should delegate to this command for consistency.
